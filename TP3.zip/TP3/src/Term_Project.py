#Term Project
from cmu_graphics import *
import random
import copy

class Player:
    def __init__(self, name, routes, color):
        self.name = name
        self.routes = routes
        self.color = color
        self.trainsLeft = 45
        self.citiesConnected = set() #add all the cities connected by the players' trains
        self.connections = set()
        self.cards = [] #append later when add cards
        self.inventory = dict()
        self.bridges = 3
        self.bridgesCost = 1
        self.score = 0

    def __repr__(self):
        return f'Name:{self.name}, Routes:{self.routes}, Cards: {self.cards}'

    def addCard(self, card):
        self.inventory[card.color] = self.inventory.get(card.color, 0) + 1
        self.cards.append(card)

    def discardCard(self, card, bank):
        colorCards = self.inventory.get(card, 0)
        loco = self.inventory.get('loco', 0)
        if card == 'loco' and loco > 0:
            self.discard('loco', bank)
        elif card  != 'loco': 
            if colorCards > 0:
                self.discard(card, bank)
            elif loco > 0:
                self.discard('loco', bank)

    def __eq__(self, other):
        if not isinstance(other, Player):
            return False
        else:
            return self.name == other.name and self.color == other.color

    def discard(self, color, bank):
        popped = None
        i = 0
        while i < len(self.cards):
            if self.cards[i].color == color:
                popped = self.cards.pop(i)
                break
            else:
                i += 1
        self.inventory[color] = self.inventory.get(color, 0) - 1
        bank.discardCards.append(popped)

class Route:
    def __init__(self, fro, to, points, taken):
        self.fro = fro
        self.to = to
        self.points = points
        self.taken = taken
        self.froPoint = (fro.x, fro.y)
        self.toPoint = (to.x, to.y)
    
    def __repr__(self):
        return f'From {self.fro} to {self.to}'

class City:
    def __init__(self,name, x, y):
        self.name = name
        self.x = x
        self.y = y
    
    def __repr__(self):
        return str(self.name)
        # return f'City: {self.name}, at point ({self.x},{self.y})'

    def __eq__(self, other):
        if not isinstance(other, City):
            return False
        else:
            return self.name == other.name
    
    def __hash__(self):
        return hash(str(self))

class SmallRoute:
    def __init__(self, color, trains, fro, to, brackets, loco, taken = None):
        self.color = color
        self.trains = trains
        self.fro = fro
        self.to = to
        self.brackets = brackets
        self.loco = loco
        self.taken = taken
    
    def __repr__(self):
        return f'From {self.fro} to {self.to} with {self.trains} {self.color} colored spaces'

class Cards:
    def __init__(self, color, number):
        self.color = color
        self.number = number

    def __repr__(self):
        return f'{self.color}-colored card'
    
    def __eq__(self, other):
        if not isinstance(other, Cards):
            return False
        else:
            return self.color == other.color and self.number == other.number

class Bank:
    def __init__(self):
        self.cards = []
        for i in range(12):
            self.cards.extend([Cards('red', i), Cards('pink', i), Cards('orange', i), Cards('yellow', i), Cards('black', i), Cards('white', i), Cards('green', i), Cards('blue', i), Cards('loco', i)])
        self.cards.extend([Cards('loco', 12), Cards('loco', 13)])
        self.downCards = []
        self.discardCards = []

        
    def giveColorCards(self, other):
        if len(self.cards) == 0 and len(self.discardCards) == 0:
            return None
        elif len(self.cards) <= 5:
            self.cards += self.discardCards
            self.discardCards = []
        rand = random.randint(0, len(self.cards)-1)
        card = self.cards.pop(rand)
        if isinstance(other, Player):
            other.addCard(card)
        elif isinstance(other, Bank):
            return card
            other.downCards.append(card)

    def discard(self):
        rand = random.randint(0, len(self.cards)-1)
        card = self.cards.pop(rand)
        self.discardCards.append(card)

class Button:
    def __init__(self, left, top, width, height):
        self.left = left
        self.top = top
        self.width = width
        self.height = height
    
    def didClick(self, mouseX, mouseY):
        return self.left <= mouseX <= self.left + self.width and self.top <= mouseY <= self.top + self.height

class Dropdown:
    def __init__(self, left, top, width, height, triggerText, open, dropdown):
        self.trigger = Button(left, top, width, height)
        self.o0, self.o1, self.o2, self.o3, self.o4, self.o5, self.o6, self.o7, self.o8, self.o9, self.o10, self.o0text, self.o1text, self.o2text, self.o3text, self.o4text, self.o5text, self.o6text, self.o7text, self.o8text, self.o9text, self.o10text = None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None, None
        self.options = [self.o0, self.o1, self.o2, self.o3, self.o4, self.o5, self.o6, self.o7, self.o8, self.o9, self.o10]
        self.texts = [self.o0text, self.o1text, self.o2text, self.o3text, self.o4text, self.o5text, self.o6text, self.o7text, self.o8text, self.o9text, self.o10text]
        for i in range(len(dropdown)):
            self.options[i] = dropdown[i]['Button']
            self.texts[i] = dropdown[i]['Label']
        self.realOptions = len(dropdown)
        self.triggerText = triggerText
        self.open = open
        self.dropdown = dropdown

trainsToPoints = {0:-4, 1:1, 2:2, 3:4, 4:7, 6:15, 8:21}

# Calculated Each cities x, y coordinate in relative to the width and height of the app
Edinburgh = City('Edinburgh', .393778, .1388236)
London = City('London', .436, .268)
Amsterdam = City('Amsterdam', .496, .267)
Essen = City('Essen', .5478, .277647)
Berlin = City('Berlin', .6107739, .290588)
Kobenhavn = City('Kobenhavn', .593323, .187059)
Stockholm = City('Stockholm', .6585736, .121176)
Petrograd = City('Petrograd', .843, .1415)
Riga = City('Riga', .73545, .145)
Danzic = City('Danzic', .6832, .22222)
Warszawa = City('Warszawa', .7143, .28254)
Wilno = City('Wilno', .7857, .261376)
Smolensk = City('Smolensk', .84987, .2656)
Moskva = City('Moskva', .90344, .243386)
Bruxelles = City('Bruxelles', .48214, .31)
Dieppe = City('Dieppe', .4279, .34353)
Frankfurt = City('Frankfurt', .5387, .337647)
Kyiv = City('Kyiv', .81032, .328235)
Kharkov  = City('Kharkov', .894, .3733334)
Brest = City('Brest', .3717754, .368669)
Paris = City('Paris', .4597876, .38162544)
Munchen = City('Munchen', .575114, .375736)
Wien = City('Wien', .646825, .389418)
Budapest = City('Budapest', .67754, .411072)
Rostov = City('Rostov', .9211, .419317)
Zurich = City('Zurich', .532625, .42992)
Venezia = City('Venezia', .585736, .457)
Zacrab = City('Zacrab', .6396, .4676)
Bucuresti = City('Bucuresti', .7739, .46996)
Sevastopol = City('Sevastopol', .86115, .482921)
Sochi = City('Sochi', .917299, .4958775)
Pamplona = City('Pamplona', .419167, .513545)
Marseille = City('Marseille', .5158333, .51)
Sarajevo = City('Sarajevo', .691799, .51746)
Sofia = City('Sofia', .73478836, .5248677)
Roma = City('Roma', .590608, .53439)
Brindisi = City('Brindisi', .64484, .556614)
Constantinople = City('Constantinople', .806217, .576716)
Erzurum = City('Erzurum', .9047619, .6031746)
Barcelona = City('Barcelona', .42724868, .5904762)
Angora = City('Angora', .854497, .62328)
Athina = City('Athina', .7228836, .621164)
Smyrna = City('Smyrna', .777778, .6444445)
Palermo = City('Palermo', .6137566, .6455)
Madrid = City('Madrid', .35582, .582)
Lisboa = City('Lisboa', .313492, .6021164)
Cadiz = City('Cadiz', .35582, .64656)
cities = [Edinburgh, London, Amsterdam, Essen, Berlin, Kobenhavn, Stockholm, Petrograd, Riga, Danzic, Warszawa, Wilno, Smolensk, Moskva, Bruxelles, Dieppe, Frankfurt, Kyiv, Kharkov, Brest, Paris, Munchen, Wien, Budapest, Rostov, Zurich, Venezia, Zacrab, Bucuresti, Sevastopol, Sochi, Pamplona, Marseille, Sarajevo, Sofia, Roma, Brindisi, Constantinople, Erzurum, Barcelona, Angora, Athina, Smyrna, Palermo, Madrid, Lisboa, Cadiz]

# I mapped the cities to the x related to app.width and y to app.height but this function will change to map.width and map.height
def normalize(app, city):
    left = app.width * 1/3 - (app.width // 20)
    top = app.height // 12
    width = app.width * 2 // 3
    height = app.height * 3 // 5

    new_mouseX = (city.x*app.width - left) / width
    new_mouseY = (city.y*app.height - top) / height

    city.x = new_mouseX
    city.y = new_mouseY

for city in cities:
    normalize(app, city)
#finding pads of trains with color recognition

EdinburghToLondon = SmallRoute(['black', 'orange'], 4, Edinburgh, London, False, 0)
KobenhavnToStockholm = SmallRoute(['yellow', 'white'], 3, Kobenhavn, Stockholm, False, 0)
EssenToKobenhavn = SmallRoute(['grey', 'grey'], 3, Essen, Kobenhavn, False, 1)
BerlinToWarszawa = SmallRoute(['pink', 'yellow'], 4, Berlin, Warszawa, False, 0)
FrankfurtToBerlin = SmallRoute(['black', 'red'], 3, Frankfurt, Berlin, False, 0)
BruxellesToParis = SmallRoute(['yellow', 'red'], 2, Bruxelles, Paris, False, 0)
ParisToFrankfurt = SmallRoute(['white', 'orange'], 3, Paris, Frankfurt, False, 0)
LondonToDieppe = SmallRoute(['grey', 'grey'], 2, London, Dieppe, False, 1)
ParisToPamplona = SmallRoute(['blue', 'green'], 4, Paris, Pamplona, False, 0)
PamplonaToMadrid = SmallRoute(['black', 'white'], 3, Pamplona, Madrid, True, 0)
WienToBudapest = SmallRoute(['red', 'white'], 1, Wien, Budapest, False, 0)
LondonToAmsterdam = SmallRoute('grey', 2, London, Amsterdam, False, 2)
AmsterdamToEssen = SmallRoute('yellow', 3, Amsterdam, Essen, False, 0)
EssenToBerlin = SmallRoute('blue', 2, Essen, Berlin, False, 0)
BerlinToDanzic = SmallRoute('grey', 4, Berlin, Danzic, False, 0)
DanzicToRiga = SmallRoute('black', 3, Danzic, Riga, False, 0)
RigaToPetrograd = SmallRoute('grey', 4, Riga, Petrograd, False, 0)
StockholmToPetrograd = SmallRoute('grey', 8, Stockholm, Petrograd, True, 0)
PetrogradToMoskva = SmallRoute('white', 4, Petrograd, Moskva, False, 0)
PetrogradToWilno = SmallRoute('blue', 4, Petrograd, Wilno, False, 0)
WilnoToRiga = SmallRoute('green', 4, Wilno, Riga, False, 0)
WilnoToSmolensk = SmallRoute('yellow', 3, Wilno, Smolensk, False, 0)
WarszawaToWilno = SmallRoute('red', 3, Warszawa, Wilno, False, 0)
WilnoToKyiv = SmallRoute('grey', 2, Wilno, Kyiv, False, 0)
SmolenskToMoskva = SmallRoute('orange', 2, Smolensk, Moskva, False, 0)
DanzicToWarszawa = SmallRoute('grey', 2, Danzic, Warszawa, False, 0)
EssenToFrankfurt = SmallRoute('green', 2, Essen, Frankfurt, False, 0)
AmsterdamToFrankfurt = SmallRoute('white', 2, Amsterdam, Frankfurt, False, 0)
AmsterdamToBruxelles = SmallRoute('black', 1, Amsterdam, Bruxelles, False, 0)
BruxellesToFrankfurt = SmallRoute('blue', 2, Bruxelles, Frankfurt, False, 0)
DieppeToParis = SmallRoute('pink', 1, Dieppe, Paris, False, 0)
BrestToDieppe = SmallRoute('orange', 2, Brest, Dieppe, False, 0)
BrestToParis = SmallRoute('black', 3, Brest, Paris, False, 0)
BrestToPamplona = SmallRoute('pink', 4, Brest, Pamplona, False, 0)
MadridToLisboa = SmallRoute('pink', 3, Madrid, Lisboa, False, 0)
LisboaToCadiz = SmallRoute('blue', 2, Lisboa, Cadiz, False, 0)
CadizToMadrid = SmallRoute('orange', 3, Cadiz, Madrid, False, 0)
MadridToBarcelona = SmallRoute('yellow', 2, Madrid, Barcelona, False, 0)
BarcelonaToPamplona = SmallRoute('grey', 2, Barcelona, Pamplona, True, 0)
BarcelonaToMarseille = SmallRoute('grey', 4, Barcelona, Marseille, False, 0)
PamplonaToMarseille = SmallRoute('red', 4, Pamplona, Marseille, False, 0)
MarseilleToParis = SmallRoute('grey', 4, Marseille, Paris, False, 0)
MarseilleToZurich = SmallRoute('pink', 2, Marseille, Zurich, True, 0)
MarseilleToRoma = SmallRoute('grey', 4, Marseille, Roma, True, 0)
ZurichToParis = SmallRoute('grey', 3, Zurich, Paris, True, 0)
DieppeToBruxelles = SmallRoute('green', 2, Dieppe, Bruxelles, False, 0)
ZurichToMunchen = SmallRoute('yellow', 2, Zurich, Munchen, True, 0)
ZurichToVenezie = SmallRoute('green', 2, Zurich, Venezia, True, 0)
MunchenToFrankfurt = SmallRoute('pink', 2, Munchen, Frankfurt, False, 0)
MunchenToVenezia = SmallRoute('blue', 2, Munchen, Venezia, True, 0)
MunchenToWien = SmallRoute('orange', 3, Munchen, Wien, False, 0)
VeneziaToRoma = SmallRoute('black', 2, Venezia, Roma, False, 0)
VeneziaToZacrab = SmallRoute('grey', 2, Venezia, Zacrab, False, 0)
RomaToBrindisi = SmallRoute('white', 2, Roma, Brindisi, False, 0)
RomaToPalermo = SmallRoute('grey', 4, Roma, Palermo, False, 1)
PalermoToBrindisi = SmallRoute('grey', 3, Palermo, Brindisi, False, 1)
PalermoToSmyrna = SmallRoute('grey', 6, Palermo, Smyrna, False, 2)
BrindisiToAthina = SmallRoute('grey', 4, Brindisi, Athina, False, 1)
WienToBerlin = SmallRoute('green', 3, Wien, Berlin, False, 0)
WienToZacrab = SmallRoute('grey', 2, Wien, Zacrab, False, 0)
WienToWarszawa = SmallRoute('blue', 4, Wien, Warszawa, False, 0)
ZacrabToBudapest = SmallRoute('orange', 2, Zacrab, Budapest, False, 0)
ZacrabToSarajevo = SmallRoute('red', 3, Zacrab, Sarajevo, False, 0)
BudapestToKyiv = SmallRoute('grey', 6, Budapest, Kyiv, True, 0)
BudapestToBucuresti = SmallRoute('grey', 4, Budapest, Bucuresti, True, 0)
BudapestToSarajevo = SmallRoute('pink', 3, Budapest, Sarajevo, False, 0)
SarajevoToAthina = SmallRoute('green', 4, Sarajevo, Athina, False, 0)
SarajevoToSofia = SmallRoute('grey', 2, Sarajevo, Sofia, True, 0)
SofiaToAthina = SmallRoute('pink', 3, Sofia, Athina, False, 0)
AthinaToSmyrna = SmallRoute('grey', 2, Athina, Smyrna, False, 1)
SofiaToBucuresti = SmallRoute('grey', 2, Sofia, Bucuresti, True, 0)
SofiaToConstantinople = SmallRoute('blue', 3, Sofia, Constantinople, False, 0)
BucurestiToKyiv = SmallRoute('grey', 4, Bucuresti, Kyiv, False, 0)
BucurestiToSevastopol = SmallRoute('white', 4, Bucuresti, Sevastopol, False, 0)
BucurestiToConstantinople = SmallRoute('yellow', 3, Bucuresti, Constantinople, False, 0)
WarszawaToKyiv = SmallRoute('grey', 4, Warszawa, Kyiv, False, 0)
KyivToKharkov = SmallRoute('grey', 4, Kyiv, Kharkov, False, 0)
KyivToSmolensk = SmallRoute('red', 3, Kyiv, Smolensk, False, 0)
MoskvaToKharkov = SmallRoute('grey', 4, Moskva, Kharkov, False, 0)
SevastopolToConstantinople = SmallRoute('grey', 4, Sevastopol, Constantinople, False, 2)
KharkovToRostov = SmallRoute('green', 2, Kharkov, Rostov, False, 0)
SevastopolToRostov = SmallRoute('grey', 4, Sevastopol, Rostov, False, 0)
SevastopolToSochi = SmallRoute('grey', 2, Sevastopol, Sochi, False, 1)
SevastopolToErzurum = SmallRoute('grey', 4, Sevastopol, Erzurum, False, 2)
RostovToSochi = SmallRoute('grey', 2, Rostov, Sochi, False, 0)
SochiToErzurum = SmallRoute('red', 3, Sochi, Erzurum, True, 0)
ErzurumToAngora = SmallRoute('black', 3, Erzurum, Angora, False, 0)
AngoraToSmyrna = SmallRoute('orange', 3, Angora, Smyrna, True, 0)
SmyrnaToConstantinople = SmallRoute('grey', 2, Smyrna, Constantinople, True, 0)
AngoraToConstantinople = SmallRoute('grey', 2, Angora, Constantinople, True, 0)
BrestToPamplona = SmallRoute('pink', 4, Brest, Pamplona, False, 0)
BrestToPamplona = SmallRoute('pink', 4, Brest, Pamplona, False, 0)
smallRoutes = [SmyrnaToConstantinople, EdinburghToLondon,DieppeToBruxelles,KobenhavnToStockholm,WilnoToKyiv,EssenToKobenhavn,BerlinToWarszawa,FrankfurtToBerlin,BruxellesToParis,ParisToFrankfurt,LondonToDieppe,ParisToPamplona,PamplonaToMadrid,WienToBudapest,LondonToAmsterdam,AmsterdamToEssen,EssenToBerlin,BerlinToDanzic,DanzicToRiga,RigaToPetrograd,StockholmToPetrograd,PetrogradToMoskva,PetrogradToWilno,WilnoToRiga,WilnoToSmolensk,WarszawaToWilno,SmolenskToMoskva,DanzicToWarszawa,EssenToFrankfurt ,AmsterdamToFrankfurt,AmsterdamToBruxelles,BruxellesToFrankfurt,DieppeToParis,BrestToDieppe,BrestToParis,BrestToPamplona,MadridToLisboa,LisboaToCadiz,CadizToMadrid,MadridToBarcelona,BarcelonaToPamplona,BarcelonaToMarseille,PamplonaToMarseille,MarseilleToParis,MarseilleToZurich,MarseilleToRoma,ZurichToParis ,ZurichToMunchen ,ZurichToVenezie,MunchenToFrankfurt ,MunchenToVenezia,MunchenToWien,VeneziaToRoma,VeneziaToZacrab,RomaToBrindisi,RomaToPalermo,PalermoToBrindisi,PalermoToSmyrna,BrindisiToAthina,WienToBerlin,WienToZacrab,WienToWarszawa,ZacrabToBudapest,ZacrabToSarajevo,BudapestToKyiv,BudapestToBucuresti,BudapestToSarajevo,SarajevoToAthina,SarajevoToSofia,SofiaToAthina,AthinaToSmyrna,SofiaToBucuresti,SofiaToConstantinople,BucurestiToKyiv,BucurestiToSevastopol,BucurestiToConstantinople,WarszawaToKyiv,KyivToKharkov,KyivToSmolensk,MoskvaToKharkov,SevastopolToConstantinople,KharkovToRostov,SevastopolToRostov,SevastopolToSochi,SevastopolToErzurum,RostovToSochi,SochiToErzurum,ErzurumToAngora,AngoraToSmyrna,AngoraToConstantinople,BrestToPamplona,BrestToPamplona]

connections = dict()
for smallRoute in smallRoutes:
    connections[smallRoute.fro] = connections.get(smallRoute.fro, set())
    connections[smallRoute.fro].add(smallRoute.to)
    connections[smallRoute.to] = connections.get(smallRoute.to, set())
    connections[smallRoute.to].add(smallRoute.fro)

#Found these on the web
cityFroToRoutes = '''Athina-Angora (5)
Budapest-Sofia (5)
Frankfurt-Kobenhavn (5)
Rostov-Erzurum (5)
Sofia-Smyrna (5)
Kyiv-Petrograd (6)
Zurich-Brindisi (6)
Zurich-Budapest (6)
Warszawa-Smolensk (6)
Zacrab-Brindisi (6)
Paris-Zacrab (7)
Brest-Marseille (7)
London-Berlin (7)
Edinburgh-Paris (7)
Amsterdam-Pamplona (7)
Roma-Smyrna (8)
Palermo-Constantinople (8)
Sarajevo-Sevastopol (8)
Madrid-Dieppe (8)
Barcelona-Bruxelles (8)
Paris-Wien (8)
Barcelona-Munchen (8)
Brest-Venezia (8)
Smolensk-Rostov (8)
Marseille-Essen (8)
Kyiv-Sochi (8)
Madrid-Zurich (8)
Berlin-Bucuresti (8)
Bruxelles-Danzic (9)
Berlin-Roma (9)
Angora-Kharkov (10)
Riga-Bucuresti (10)
Essen-Kyiv (10)
Venezia-Constantinople (10)
London-Wien (10)
Athina-Wilno (11)
Stockholm-Wien (11)
Berlin-Moskva (12)
Amsterdam-Wilno (12)
Frankfurt-Smolensk (13)'''

longRoutes = '''Lisboa-Danzic (20)
Brest-Petrograd (20)
Palermo-Moskva (20)
Kobenhavn-Erzurum (21)
Edinburgh-Athina (21)
Cadiz-Stockholm (21)'''

def getFroToPoints(lines):
    fro = []
    to = []
    points = []
    for line in lines.splitlines():
        fromCity, toCityPoints = line.split('-')
        toCity, point = toCityPoints.split(' (')
        actualPoints = ''
        for num in point:
            if num.isdigit():
                actualPoints += num
        fro.append(fromCity)
        to.append(toCity)
        points.append(int(actualPoints))
    return fro, to, points

fro, to, points = getFroToPoints(cityFroToRoutes)
longFro, longTo, longPoints = getFroToPoints(longRoutes)

def getRoutes(number,fro, to, points, player):
    routes = []
    for i in range(number):
        rand = random.randint(0,len(fro)-1)
        froCity = fro.pop(rand)
        toCity = to.pop(rand)
        for city in cities:
            if froCity == city.name:
                froCity = city
            elif toCity == city.name:
                toCity = city
        route = Route(froCity, toCity, points.pop(rand), player)  
        routes.append(route)
    return routes

def initializePlayer(name, color):
    player1 = Player(name, None, color)
    player1.routes = getRoutes(1, longFro, longTo, longPoints, player1)
    player1.routes.extend(getRoutes(3, fro, to, points, player1))
    return player1


def onAppStart(app):
    app.trainsToPoints = {0:-4, 1:1, 2:2, 3:4, 4:7, 6:15, 8:21}

    app.prevWidth = app.width
    app.prevHeight = app.height
    #got board from here 'https://cf.geekdo-images.com/34etSTfl-aa9hsi1gd2MZw__original/img/nhBqtw6ISU8K544rFQ2jPuyBDtM=/0x0/filters:format(jpeg)/pic70732.jpg'
    app.url = 'Images/TicketToRide.webp'
    # got cards from this linkhttps://boardgamegeek.com/image/3493864/ticket-to-ride-europe"
    app.yellowCard = 'Images/YellowColorCard.png'
    app.redCard = 'Images/RedColorCard.png'
    app.orangeCard = 'Images/OrangeColorCard.png'
    app.locoCard = 'Images/LocoColorCard.png'
    app.blueCard = 'Images/BlueColorCard.png'
    app.blackCard = 'Images/BlackColorCard.png'
    app.greenCard = 'Images/GreenColorCard.png'
    app.pinkCard = 'Images/PinkColorCard.png'
    app.whiteCard = 'Images/WhiteColorCard.png'
    app.randomCardImage = 'Images/RandomCard.png'
    
    #from here http://www.gamingcorner.nl/rules/boardgames/ticket%20to%20ride%20europe_uk.pdf
    app.manual0 = 'Images/TTRE_Manual-1.jpg'
    app.manual1 = 'Images/TTRE_Manual-2.jpg'
    app.manual2 = 'Images/TTRE_Manual-3.jpg'
    app.manual3 = 'Images/TTRE_Manual-4.jpg'
    app.manual4 = 'Images/TTRE_Manual-5.jpg'
    app.manual5 = 'Images/TTRE_Manual-6.jpg'
    app.manual6 = 'Images/TTRE_Manual-7.jpg'
    app.manual7 = 'Images/TTRE_Manual-8.jpg'
    app.manuals = [app.manual0, app.manual1, app.manual2, app.manual3, app.manual4, app.manual5, app.manual6, app.manual7]
    app.title = 'Images/title.png' #https://www.unboxnow.com/ticket-to-ride-europe

    app.podium = 'Images/podium.jpeg'

    reset(app)

def reset(app):
    for smallRoute in smallRoutes:
        smallRoute.taken = None
    app.instructions = False
    app.instructPage = 0
    app.gameOver = False
    app.highlight = None
    app.paused = False
    app.currentPlayer = None
    app.colorCards=[ 'blue', 'pink', 'red', 'green', 'orange', 'yellow', 'white', 'black', 'loco']
    app.playerColorOptions = ['salmon', 'dimGray', 'lightSkyBlue', 'paleGreen', 'lightGoldenrodYellow']
    app.player1, app.player2, app.player3, app.playeer4, app.player5 = None, None, None, None, None
    app.players = [app.player1, app.player2, app.player3, app.playeer4, app.player5]
    app.currentTurnOver = False
    app.buildMode = False
    app.message = ''
    app.selectedCity = None

    app.bank = Bank()
    app.colorCount = 0
    for card in app.bank.downCards:
        if card != None and card.color == 'loco':
            app.colorCount += 1
    
    while app.colorCount >= 3:
        for i in range(len(app.bank.downCards)):
            app.colorCount = 0
            app.bank.discardCards.append(app.bank.downCards[i])
            app.bank.downCards[i] = app.bank.giveColorCards(app.bank)
            if app.bank.downCards[i] != None and app.bank.downCards[i].color == 'loco':
                app.colorCount += 1
    
    app.player1Color, app.player2Color, app.player3Color, app.player4Color, app.player5Color = None, None, None, None, None
    app.playerDropdowns = [app.player1Color, app.player2Color, app.player3Color, app.player4Color, app.player5Color]
    app.player1Colored, app.player2Colored, app.player3Colored, app.player4Colored, app.player5Colored = None, None, None, None, None
    app.playerColors = [app.player1Colored, app.player2Colored, app.player3Colored, app.player4Colored, app.player5Colored]
    app.player1Name, app.Player2Name, app.Player3Name, app.player4Name, app.player5Name = None, None, None, None, None
    app.playerNames = [app.player1Name, app.Player2Name, app.Player3Name, app.player4Name, app.player5Name]
    app.player1Submit, app.Player2Submit, app.Player3Submit, app.player4Submit, app.player5Submit = None, None, None, None, None
    app.playerSubmits = [app.player1Submit, app.Player2Submit, app.Player3Submit, app.player4Submit, app.player5Submit]
    app.player1NameButton, app.Player2NameButton, app.Player3NameButton, app.player4NameButton, app.player5NameButton = None, None, None, None, None
    app.playerNameButtons = [app.player1NameButton, app.Player2NameButton, app.Player3NameButton, app.player4NameButton, app.player5NameButton]

    for i in range(len(app.playerNames)):
        app.playerNames[i] = f'Unnamed{i+1}'

    getAppButtons(app)
    app.highlightCity1 = None
    app.highlightCity2 = None

    app.selectCity1 = None
    app.selectCity2 = None
    app.cardsTakenCount = 0
    app.isQuestionStatement = 0
    app.currentDropdown = None
    app.selectedDropdownText = None
    app.tunnelFlag = False
    app.extra = 0
    app.discardCount = 0
    app.numPlayers = 2
    app.currPlayers = None
    app.gameStart = True
    app.prevCurrPlayers = None
    app.currentName = None
    app.currentDropdownIndex = None
    app.submitFlag = 0
    app.whoHas2 = None
    app.playerHas2 = False
    app.lastFlag = 0

    



def getAppButtons(app):
    app.instructButton = Button(app.width//40, app.height *3//5 + app.height//7, app.width//4, app.height//20)
    app.instructBack = Button(app.width//10, app.height * 11//12, app.width//5, app.height//13)
    app.instructNext = Button(app.width - app.width//10 - app.width//5, app.height * 11//12, app.width//5, app.height//13)
    app.instructHome = Button(app.width//2-app.width//20, app.height * 9//10, app.width//10, app.height//11)
    app.gameRestart = Button(app.width//10, app.height//10, app.width//6, app.height//16)
    app.submit = Button(app.width*1//6, app.height *11//12, app.width//6, app.height//18)


    app.randomCard = Button(app.width//120, app.height//10, app.width//18, app.height//8)
    left, top, width, height = app.width//120, app.height//4, app.width//22, app.height//10
    app.downCard0, app.downCard1, app.downCard2, app.downCard3, app.downCard4 = None, None, None, None, None
    app.downCards = [app.downCard0, app.downCard1, app.downCard2, app.downCard3, app.downCard4]
    for i in range(len(app.downCards)):
        app.downCards[i] = Button(left, top, width,height)
        left = left + 1.2 * width
    
    app.RYPlayer = Button(app.width//3, app.height//3, app.width//3, app.height//3)

    left, top, width, height = (app.width//120, app.height*5//6, app.width//12, app.height//6) #if not app.buildMode else (app.width//7, app.height*10//11, app.width//12, app.height//11)
    app.routeCard0, app.routeCard1, app.routeCard2, app.routeCard3 = None, None, None, None
    app.routeCards = [app.routeCard0, app.routeCard1, app.routeCard2, app.routeCard3]
    for i in range(len(app.routeCards)):
        app.routeCards[i] = Button(left, top, width,height)
        left = left + 1.2 * width

    app.cities = [Edinburgh, London, Amsterdam, Essen, Berlin, Kobenhavn, Stockholm, Petrograd, Riga, Danzic, Warszawa, Wilno, Smolensk, Moskva, Bruxelles, Dieppe, Frankfurt, Kyiv, Kharkov, Brest, Paris, Munchen, Wien, Budapest, Rostov, Zurich, Venezia, Zacrab, Bucuresti, Sevastopol, Sochi, Pamplona, Marseille, Sarajevo, Sofia, Roma, Brindisi, Constantinople, Erzurum, Barcelona, Angora, Athina, Smyrna, Palermo, Madrid, Lisboa, Cadiz]

    app.endTurn = Button(app.width//20, app.height *3//5, app.width//5, app.height//8)

    app.builds = [Button(app.width//20, app.height *3//5 - app.height//6, app.width//5, app.height//8), Button(app.width//50, app.height *10//11, app.width//8, app.height//12)]
    app.build = app.builds[0] if not app.buildMode else app.builds[1]

    left, top, width, height = app.width//14, -10, app.width // 5,app.height//8 + 10 + app.height//10
    app.currLobby = Button(left, top, width, height)
    left = left+width*1.1
    if len(app.players) > 4:
        width = app.width // 6.5
    app.lobby1, app.lobby2, app.lobby3, app.lobby4 = None, None, None, None
    app.lobbys = [app.currLobby, app.lobby1, app.lobby2, app.lobby3, app.lobby4]
    players = copy.copy(app.players)
    height = 10 + app.height//15
    for i in range(len(players)-1):
        newPlayer = toggleList(players, app.currentPlayer)
        if newPlayer != None:
            app.lobbys[i+1] = Button(left, top, width, height)
            left = left + width*1.1
    
    left, top, width, height = app.width*5//6-app.width//24, app.height//4, app.width // 6,app.height//8 + 10 + app.height//10
    app.currLead = Button(left, top, width, height)
    # if len(app.players) > 4:
    #     width = app.width // 6
    app.lead1, app.lead2, app.lead3, app.lead4 = None, None, None, None
    app.leads = [app.currLead, app.lead1, app.lead2, app.lead3, app.lead4]
    players = copy.copy(app.players)
    for i in range(len(players)-1):
        left = left - width*1.13
        top = top + height//2.5
        newPlayer = toggleList(players, app.currentPlayer)
        if newPlayer != None:
            app.leads[i+1] = Button(left, top, width, height)
    
    app.mapHeights = [app.height * 3 // 5, app.height*8//9]
    app.mapWidths = [app.width * 2 // 3, app.width]
    app.mapLefts = [app.width *1/3 - (app.width//20), 0]
    app.mapTops = [app.height//12, 0]
    app.mapHeight = app.mapHeights[0] if not app.buildMode else app.mapHeights[1]
    app.mapWidth = app.mapWidths[0] if not app.buildMode else app.mapWidths[1]
    app.mapLeft = app.mapLefts[0] if not app.buildMode else app.mapLefts[1]
    app.mapTop = app.mapTops[0] if not app.buildMode else app.mapTops[1]

    app.yes = Button(app.width//3, app.height//2, app.width//6, app.height//6)
    app.ok = Button(app.width//3, app.height//2, app.width//3, app.height//6)
    app.no = Button(app.width//2, app.height//2, app.width//6, app.height//6)
    app.questionMessage = ''
    app.smallRoute = None

    left, top, width, height = app.width//3, app.height//60, app.width // 30,app.height//25
    app.players2, app.players3, app.players4, app.players5 = None, None, None, None
    app.playersNum = [app.players2, app.players3, app.players4, app.players5]
    for i in range(len(app.playersNum)):
        app.playersNum[i] = Button(left, top, width,height)
        left = left + 1.1 * width

def toggleList(list, item):
    curr = list.index(item)
    return list[(curr+1)%len(list)]

def makeColorDropdowns(app, left, top, width, height, triggerText, numPlayers):
    bottom = app.height*9//10
    section = (bottom-top)//(numPlayers) + height
    
    for i in range(numPlayers):
        bottom = app.height*9//10
        if app.playerDropdowns[i] == None:
            app.playerDropdowns[i] = makeColorDropdown(app, left, top, width, height, triggerText, i)
            app.playerNameButtons[i] = Button(left - app.width//4, top, width, 1.5*height)
            if not isinstance(app.playerSubmits[i], bool):
                app.playerSubmits[i] = Button(left + width *1.5 , top, width, 1.2*height)
        top = top + section

def makeColorDropdown(app, left, top, width, height, triggerText, i):
    triggerText = triggerText + str(i+1) if app.playerColors[i] == None else app.playerColors[i]
    colors = copy.copy(app.playerColorOptions)
    for color in app.playerColors:
        if color in colors:
            colors.pop(colors.index(color))
    dropDown = []
    nextTop = top
    for color in colors:
        nextTop += height
        dropDown.append({'Label': str(color), 'Button': Button(left, nextTop, width, height)})
    return Dropdown(left, top, width, height, triggerText, False, dropDown)

def onKeyRelease(app,key):
    if isinstance(app.currentName, int):
        if len(app.playerNames[app.currentName]) <= 10:
            if key in 'QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890':
                if app.playerNames[app.currentName] == f'Unnamed{app.currentName+1}':
                    app.playerNames[app.currentName] = ''
                app.playerNames[app.currentName] += key
            elif key == 'backspace':
                app.playerNames[app.currentName] = app.playerNames[app.currentName][:-1]
            elif key == 'enter':
                app.currentName = None

            
        


    pass

def loadGame(app):
    app.player1 = initializePlayer("Player1", "red")
    app.player2 = initializePlayer("Player2", "blue")
    app.player3, app.player4, app.player5 = None, None, None
    
    app.players = [app.player1, app.player2, app.player3, app.player4, app.player5]
        
    app.player1.routes = [Route(Palermo, Moskva, 20, app.player1), Route(Athina, Angora, 5, app.player1), Route(Sofia, Smyrna, 5, app.player1), Route(Palermo, Constantinople, 8, app.player1)]

    app.player2.routes = [Route(Brest, Petrograd, 20, app.player2), Route(Frankfurt, Smolensk, 13, app.player2), Route(Frankfurt, Kobenhavn, 5, app.player2), Route(Brest, Venezia, 8, app.player2)]

    app.player1.citiesConnected = {(Palermo, Smyrna, 6), (Athina, Smyrna, 2),(Angora, Smyrna, 3), (Angora, Constantinople, 2),(Sofia, Constantinople, 3), (Sofia, Bucuresti, 2),(Budapest, Bucuresti, 4), (Budapest, Kyiv, 6),(Kyiv, Smolensk, 3), (Smolensk, Moskva, 2),(Moskva, Kharkov, 4), (Kyiv, Kharkov, 4)}
    for (fro,to,trains) in app.player1.citiesConnected:
        app.player1.score += app.trainsToPoints[trains]
    player1Connection = list(set([Palermo, Smyrna, Athina, Smyrna,Angora, Smyrna, Angora, Constantinople,Sofia, Constantinople, Sofia, Bucuresti,Budapest, Bucuresti, Budapest, Kyiv,Kyiv, Smolensk, Smolensk, Moskva,Moskva, Kharkov, Kyiv, Kharkov]))
    for i in range(len(player1Connection)):
        for j in range(i, len(player1Connection)):
            app.player1.connections.add((player1Connection[i], player1Connection[j]))

    for (fro, to, points) in app.player1.citiesConnected:
        smallRoute = findSmallRoute(app, smallRoutes, fro, to)
        smallRoute.taken = app.player1
    app.player1.trainsLeft = 4
    app.player2.citiesConnected = {(Brest, Paris, 3), (Zurich, Paris, 3),(Zurich, Venezia, 2), (Munchen, Venezia, 2),(Munchen, Frankfurt, 2), (Essen, Frankfurt, 2),(Essen, Kobenhavn, 3), (Kobenhavn, Stockholm, 3),(Stockholm, Petrograd, 8), (Petrograd, Wilno, 4),(Wilno, Smolensk, 3), (Wilno, Riga, 4), (Danzic, Riga, 3)}
    for (fro,to,trains) in app.player2.citiesConnected:
        app.player2.score += app.trainsToPoints[trains]
    app.player2.connections = {(Brest, Paris), (Zurich, Paris),(Zurich, Venezia), (Munchen, Venezia),(Munchen, Frankfurt), (Essen, Frankfurt),(Essen, Kobenhavn), (Kobenhavn, Stockholm),(Stockholm, Petrograd), (Petrograd, Wilno),(Wilno, Smolensk), (Wilno, Riga), (Danzic, Riga)}
    player2Connection = list(set([Brest, Paris, Zurich, Paris,Zurich, Venezia, Munchen, Venezia,Munchen, Frankfurt, Essen, Frankfurt,Essen, Kobenhavn, Kobenhavn, Stockholm,Stockholm, Petrograd, Petrograd, Wilno,Wilno, Smolensk, Wilno, Riga, Danzic, Riga]))
    for i in range(len(player2Connection)):
        for j in range(i, len(player2Connection)):
            app.player2.connections.add((player2Connection[i], player2Connection[j]))

    for (fro, to, points) in app.player2.citiesConnected:
        smallRoute = findSmallRoute(app, smallRoutes, fro, to)
        smallRoute.taken = app.player2
    app.player2.trainsLeft = 3
    app.gameStart = False
    
    app.currentPlayer = app.players[0]
    i = 0
    while i < len(app.players):
        if app.players[i] == None or i>=app.numPlayers:
            app.players.pop(i)
        else:
            i+= 1
    for i in range(5):
        for _ in range(4):
            for player in app.players:
                app.bank.giveColorCards(player)
        app.bank.downCards.append(app.bank.giveColorCards(app.bank)) 
    app.gameStart = False
    getAppButtons(app)
    pass

def onKeyHold(app, keys):
    if app.gameStart and 'tab' in keys and 's' in keys:
        loadGame(app)
    elif 'tab' in keys and 'r' in keys:
        reset(app)

def onMousePress(app, mouseX, mouseY):

    if app.submitFlag ==1:
        app.submitFlag = 0
        pass
    if app.width != app.prevWidth or app.height != app.prevHeight:
        app.prevWidth = app.width
        app.prevHeight = app.height
        getAppButtons(app)
    if not app.currentTurnOver:
        app.highlightCity1 = None
        app.highlightCity2 = None
        app.currentName = None
    if app.buildMode == False and not app.gameStart:
        app.currentDropdown = None
        app.selectedDropdownText = None
        app.tunnelFlag = False
    if app.gameStart:
        for players in app.playersNum:
            if players.didClick(mouseX, mouseY):
                app.currPlayers = players
        if app.currPlayers != None and (app.prevCurrPlayers == None or app.prevCurrPlayers != app.currPlayers):
            app.prevCurrPlayers = app.currPlayers
            app.numPlayers = app.playersNum.index(app.currPlayers) + 2
            for i in range(len(app.playerDropdowns)):
                app.playerDropdowns[i] = None

            makeColorDropdowns(app, app.width//3, app.playersNum[0].top+app.playersNum[0].height+app.height//75, app.width//6, app.height//30, 'Color of Player', app.numPlayers)
        elif app.submit.didClick(mouseX, mouseY):
            for i in range(app.numPlayers):
                if type(app.playerSubmits[i]) != bool:
                    return
            app.currentPlayer = app.players[0]
            i = 0
            while i < len(app.players):
                if app.players[i] == None or i>=app.numPlayers:
                    app.players.pop(i)
                else:
                    i+= 1
            for i in range(5):
                for _ in range(4):
                    for player in app.players:
                        app.bank.giveColorCards(player)
                app.bank.downCards.append(app.bank.giveColorCards(app.bank))
            for index in range(len(app.bank.downCards)):
                if app.bank.downCards[index] != None and app.bank.downCards[index].color == 'loco':
                    app.colorCount += 1
            app.gameStart = False
            getAppButtons(app)
        
        elif app.currPlayers != None:
            for i in range(len(app.playerDropdowns)):
                if app.playerDropdowns[i] != None:
                    flag = 0
                    for j in range(len(app.playerSubmits[:i])):
                            if not isinstance(app.playerSubmits[j], bool):
                                flag = 1
                    if flag == 1:
                        break
                    elif app.playerNameButtons[i].didClick(mouseX, mouseY) and type(app.playerSubmits[i]) != bool:
                        app.currentName = i
                    elif type(app.playerSubmits[i]) != bool and app.playerSubmits[i].didClick(mouseX, mouseY) and app.playerDropdowns[i].triggerText.find('Color') == -1:

                        app.playerSubmits[i] = True
                        app.players[i] = initializePlayer(app.playerNames[i], app.playerColors[i])
                        makeColorDropdowns(app, app.width//3, app.playersNum[0].top+app.playersNum[0].height+app.height//75, app.width//6, app.height//30, 'Color of Player', app.numPlayers)
                    elif type(app.playerSubmits[i]) != bool and app.playerSubmits[i].didClick(mouseX, mouseY):
                        app.submitFlag = 1
                    elif app.playerDropdowns[i].trigger.didClick(mouseX, mouseY):
                        # app.playerDropdowns[i].open
                        app.currentDropdown = app.playerDropdowns[i]
                        app.currentDropdownIndex = i
                        if type(app.playerSubmits[i]) != bool:
                            app.currentDropdown.open = not app.currentDropdown.open
                        for j in range(len(app.playerDropdowns)):
                            if app.playerDropdowns[j] != None and app.playerDropdowns[j] != app.currentDropdown:
                                app.playerDropdowns[j].open = False
                        break
            if app.currentDropdown != None and app.currentDropdown.open:
                for i in range(app.currentDropdown.realOptions):
                    if app.currentDropdown.options[i].didClick(mouseX, mouseY) and not app.currentDropdown.texts[i] in app.playerColors:
                        app.selectedDropdownText = app.currentDropdown.texts[i]
                        app.currentDropdown.triggerText = app.selectedDropdownText
                        app.playerColors[app.currentDropdownIndex] = app.selectedDropdownText
                        app.currentDropdown.open = False

            else:
                pass
    elif app.instructions:
        if app.instructNext.didClick(mouseX, mouseY) and app.instructPage < 3:
            app.instructPage += 1
        elif app.instructBack.didClick(mouseX, mouseY) and app.instructPage > 0:
            app.instructPage -= 1
        elif app.instructHome.didClick(mouseX, mouseY):
            app.instructions = False
    elif app.gameOver:
        if app.gameRestart.didClick(mouseX, mouseY):
            reset(app)
    # app.message = f' {(mouseX / app.width)} , {(mouseY / app.height)}'
    elif app.buildMode == False and app.instructButton.didClick(mouseX, mouseY) and not app.isQuestionStatement:
        app.instructions = True
    elif app.currentTurnOver == True and app.endTurn.didClick(mouseX, mouseY) and not app.buildMode and not app.isQuestionStatement:
        if app.lastFlag == 1:
            app.gameOver = True
            getPlayerScores(app, app.players)
            app.players = sorted(app.players, key=lambda x: x.score, reverse = True)  #https://www.geeksforgeeks.org/sorting-objects-of-user-defined-class-in-python/
            for i in range(len(app.players)):
                print(app.players[i], app.players[i].score)
            return
        app.currentTurnOver = 'Almost'
        app.currentPlayer = toggleList(app.players, app.currentPlayer)
    elif app.currentTurnOver == 'Almost' and app.RYPlayer.didClick(mouseX, mouseY) and not app.buildMode and not app.isQuestionStatement:
        app.currentTurnOver = False
    elif not app.currentTurnOver and app.randomCard.didClick(mouseX, mouseY) and not app.buildMode and not app.isQuestionStatement:
        if app.whoHas2 == app.currentPlayer:
            app.lastFlag = 1
        app.bank.giveColorCards(app.currentPlayer)
        app.cardsTakenCount += 1
    elif not app.currentTurnOver and clickDownCard(app.downCards,mouseX, mouseY) and not app.buildMode and not app.isQuestionStatement:
        if app.whoHas2 == app.currentPlayer:
            app.lastFlag = 1
        index = getDownIndex(app.downCards, mouseX, mouseY)
        if app.bank.downCards[index] != None:
            if app.bank.downCards[index].color == 'loco' and app.cardsTakenCount == 0:
                app.currentPlayer.addCard(app.bank.downCards[index])
                app.cardsTakenCount += 2
                app.colorCount -= 1
                app.bank.downCards[index] =  app.bank.giveColorCards(app.bank)
                if app.bank.downCards[index] != None and app.bank.downCards[index].color == 'loco':
                    app.colorCount += 1
            elif app.bank.downCards[index].color != 'loco' and app.cardsTakenCount <2:
                app.currentPlayer.addCard(app.bank.downCards[index])
                app.cardsTakenCount += 1
                app.bank.downCards[index] =  app.bank.giveColorCards(app.bank)
                if app.bank.downCards[index] != None and app.bank.downCards[index].color == 'loco':
                    app.colorCount += 1
                while app.colorCount >= 3:
                    for i in range(len(app.bank.downCards)):
                        app.colorCount = 0
                        app.bank.discardCards.append(app.bank.downCards[i])
                        app.bank.downCards[i] = app.bank.giveColorCards(app.bank)
                        if app.bank.downCards[i] != None and app.bank.downCards[i].color == 'loco':
                            app.colorCount += 1
    elif app.currentTurnOver != 'Almost' and clickRouteCard(app.routeCards, mouseX, mouseY) and not app.buildMode and not app.isQuestionStatement:
        index = getRouteIndex(app.routeCards, mouseX, mouseY)
        highlightCities(app, app.currentPlayer.routes[index].fro, app.currentPlayer.routes[index].to)
    elif not app.currentTurnOver and app.cardsTakenCount == 0 and app.build.didClick(mouseX, mouseY):
        app.buildMode = not app.buildMode
        app.build = toggleList(app.builds, app.build)
        app.mapHeight = toggleList(app.mapHeights, app.mapHeight)
        app.mapWidth = toggleList(app.mapWidths, app.mapWidth)
        app.mapLeft = toggleList(app.mapLefts, app.mapLeft)
        app.mapTop = toggleList(app.mapTops, app.mapTop)
    elif not app.currentTurnOver and app.buildMode == True and app.isQuestionStatement == 0:
        if app.selectCity1 == None:
            app.selectCity1 = getClosestCity(app, cities, mouseX, mouseY)
            app.highlightCity1 = app.selectCity1
        else:
            app.selectCity2 = getClosestCity(app, cities, mouseX, mouseY)
            if not checkIsPossible(app, app.currentPlayer, connections, app.selectCity1, app.selectCity2):
                app.isQuestionStatement = 2
            else:
                app.smallRoute = findSmallRoute(app, smallRoutes, app.selectCity1, app.selectCity2)
                if app.smallRoute.trains > app.currentPlayer.trainsLeft or (app.smallRoute.fro, app.smallRoute.to) in app.currentPlayer.citiesConnected:
                    app.isQuestionStatement = 2
                else:
                    app.isQuestionStatement = 1
    elif app.isQuestionStatement == 2 and app.ok.didClick(mouseX, mouseY):
        app.isQuestionStatement = 0
        app.selectCity1 = None
        app.selectCity2 = None
    elif app.isQuestionStatement == 1:
        if app.yes.didClick(mouseX, mouseY):
            if app.smallRoute.color == 'grey' or app.smallRoute.color == 'gray' or isinstance(app.smallRoute.color, list):
                app.isQuestionStatement = 3
                app.currentDropdown = makePlayerDropdown(app.currentPlayer, app.smallRoute, app.width//3, app.height//2, app.width//6, app.height//20, 'Choose Color')
            else:
                if not app.smallRoute.brackets:
                    built(app)
                else:
                    app.discardCount = 0
                    for _ in range(3):
                        if len(app.bank.cards) > 0:
                            app.bank.discard()
                            app.discardCount += 1
                    color = app.selectedDropdownText if app.selectedDropdownText != None else app.smallRoute.color
                    app.tunnelFlag = playerHasEnough(app, color, app.currentPlayer, app.bank)
                    app.isQuestionStatement = 4
        elif app.no.didClick(mouseX, mouseY):
            app.isQuestionStatement *= 0
            app.selectCity1 = None
            app.selectCity2 = None
            app.smallRoute = None
    elif app.isQuestionStatement ==3:
        if app.no.didClick(mouseX, mouseY):
            app.isQuestionStatement *= 0
            app.selectCity1 = None
            app.selectCity2 = None
            app.smallRoute = None
        else:
            if app.currentDropdown.trigger.didClick(mouseX, mouseY):
                app.currentDropdown.open = not app.currentDropdown.open
            else:
                if app.currentDropdown.open:
                    for i in range(app.currentDropdown.realOptions):
                        if app.currentDropdown.options[i].didClick(mouseX, mouseY):
                            app.selectedDropdownText = app.currentDropdown.texts[i]
                            if not app.smallRoute.brackets:
                                built(app)
                            else:
                                app.discardCount = 0
                                for _ in range(3):
                                    if len(app.bank.cards) > 0:
                                        app.bank.discard()
                                        app.discardCount += 1
                                color = app.selectedDropdownText if app.selectedDropdownText != None else app.smallRoute.color
                                app.tunnelFlag = playerHasEnough(app, color, app.currentPlayer, app.bank)
                                app.isQuestionStatement = 4  
                app.currentDropdown.open = False
    elif app.isQuestionStatement ==4:
        if app.tunnelFlag:
            if app.yes.didClick(mouseX, mouseY):
                built(app)
            elif app.no.didClick(mouseX, mouseY):
                app.isQuestionStatement *= 0
                app.selectCity1 = None
                app.selectCity2 = None
                app.smallRoute = None
                app.buildMode = False
                getAppButtons(app)
                app.currentTurnOver = True
                
        else:
            if app.ok.didClick(mouseX, mouseY):
                app.isQuestionStatement *= 0
                app.selectCity1 = None
                app.selectCity2 = None
                app.smallRoute = None
                app.buildMode = False
                getAppButtons(app)
                app.currentTurnOver = True        
    if app.cardsTakenCount == 2:
        app.currentTurnOver = True
        app.cardsTakenCount = 0

def getPlayerScores(app, players):
    # bestNum = 0
    # bestP = set()
    for i in range(len(players)):
        # connections = players[i].connections
        # highest = getHighestTrains(connections)
        # if highest > bestNum:
        #     bestNum = highest
        #     bestP = set()
        #     bestP.add(i)
        # elif highest == bestNum:
        #     bestP.add(i)
        app.players[i].score += getPlayerScore(app, players[i])
    # for i in bestP:
    #     app.players[i].score += 10
    


def getPlayerScore(app, player):
    score = 0
    # conn = set()
    # for (fro, to, trains) in connections:
    #     conn.add((fro,to))
    for route in player.routes:
        if playerDidRoute(player, route):
            score += route.points
        else:
            score -= route.points
    score += player.bridges * 4
    return score

def playerDidRoute(player, route):
    if (route.fro, route.to) in player.connections or (route.to, route.fro) in player.connections:
        return True
    else:
        return False

            

def getHighestTrains(connections):
    highest = 0
    for (fro, to, trains) in connections:
        if trains > highest:
            highest = trains
    return highest

def built(app):
    addedSet(app,app.selectCity1, app.selectCity2)
    app.currentPlayer.citiesConnected.add((app.selectCity1, app.selectCity2, app.smallRoute.trains))
    app.currentPlayer.score += app.trainsToPoints[app.smallRoute.trains]
    if isinstance(app.smallRoute.color, list):
        col = app.selectedDropdownText if app.smallRoute.color[0] != 'grey' else 'grey'
        app.smallRoute.color = toggleList(app.smallRoute.color, col)                    
    else:
        app.smallRoute.taken = app.currentPlayer
    color = app.smallRoute.color
    if app.smallRoute.taken == None or app.smallRoute.color == 'grey':
        color = app.selectedDropdownText 
    takeCards(app,app.currentPlayer, app.smallRoute, color, app.bank)                            
    app.isQuestionStatement *= 0
    app.selectCity1 = None
    app.selectCity2 = None
    app.smallRoute = None
    app.buildMode = False
    getAppButtons(app)
    app.currentTurnOver = True

def addedSet(app,city1, city2):
    city1List = [city1]
    city2List = [city2]
    for (fro, to) in app.currentPlayer.connections:
        if fro == city1:
            city1List.append(to)
        elif fro == city2:
            city2List.append(to)
        elif to == city1:
            city1List.append(fro)
        elif to == city2:
            city2List.append(fro)
    totalList = list(set(city1List + city2List))
    for i in range(len(totalList)):
        for j in range(i,len(totalList)):
            app.currentPlayer.connections.add((totalList[i], totalList[j]))
    

def playerHasEnough(app,color, player, bank):
    loco = player.inventory.get('loco', 0)
    count = player.inventory.get(color, 0)
    extra = getLastfewDiscard(app,color, bank)
    app.extra = extra
    number = app.smallRoute.trains + extra
    if color != 'loco':
        if count + loco >= number:
            return True
    else:
        if loco >= number:
            return True

def getLastfewDiscard(app, color, bank):
    car = -1 * app.discardCount if app.discardCount != 0 else len(bank.discardCards)
    lastfew = bank.discardCards[car:]
    count = 0
    for card in lastfew:
        if card.color == 'loco' or card.color == color:
            count += 1
    return count


def makePlayerDropdown(player, smallRoute, left, top, width, height, triggerText):
    colors = []
    inv = player.inventory.copy()
    # if player.inventory.get('loco', 0) >= smallRoute.loco:
    inv['loco'] = inv.get('loco', 0) - smallRoute.loco
    loco = 0
    # if 'loco' in inv:
    loco += inv['loco']
    if smallRoute.color == 'grey' or smallRoute.color == 'gray':
        for color in player.inventory:
            if color != 'loco':
                if player.inventory.get(color, 0) + loco >= smallRoute.trains - smallRoute.loco:
                    colors.append(color)
            else:
                if loco >= smallRoute.trains - smallRoute.loco:
                    colors.append('loco')
    elif isinstance(smallRoute.color, list):
        for color in smallRoute.color:
            if color != 'grey' and color != 'gray':
                if player.inventory.get(color, 0) + loco >= smallRoute.trains - smallRoute.loco:
                    colors.append(color)
            else:
                for color in player.inventory:
                    if color != 'loco':
                        if player.inventory.get(color, 0) + loco >= smallRoute.trains - smallRoute.loco:
                            colors.append(color)
                    else:
                        if loco >= smallRoute.trains - smallRoute.loco:
                            colors.append('loco')
                break
    dropDown = []
    nextTop = top
    for color in colors:
        nextTop += height
        dropDown.append({'Label': str(color), 'Button': Button(left, nextTop, width, height)})
    return Dropdown(left, top, width, height, triggerText, False, dropDown)

def takeCards(app,player, smallRoute, color, bank):
    if app.whoHas2 == app.currentPlayer:
        app.lastFlag = 1
    player.trainsLeft -= smallRoute.trains
    if player.trainsLeft <= 2 and app.whoHas2 == None:
        app.playerHas2 = True
        app.whoHas2 = player
    for i in range(smallRoute.loco):
        player.discardCard('loco', bank)
    needed = smallRoute.trains - smallRoute.loco
    if app.tunnelFlag:
        needed += getLastfewDiscard(app, color, bank)
    for i in range(needed):
        player.discardCard(color, bank)

def findSmallRoute(app, smallRoutes, city1, city2):
    for smallRoute in smallRoutes:
        if (city1 == smallRoute.fro and city2 == smallRoute.to) or (city1 == smallRoute.to and city2 == smallRoute.fro):
            return smallRoute
    return None

def checkIsPossible(app, player, connections, city1, city2):
    smallRoute = None
    if city2 in connections[city1]:
        print('smallRoute')
        smallRoute = findSmallRoute(app, smallRoutes, city1, city2)
        if smallRoute.taken != None:
            print('taken')
            return False
    else:
        print('noConnect')
        return False
    
    print('noFunds')
    return haveFunds(player.inventory, smallRoute)

def haveFunds(inventory, smallRoute):
    inv = inventory.copy()
    if inventory.get('loco', 0) < smallRoute.loco:
        return False
    else:
        inv['loco'] = inv.get('loco', 0) - smallRoute.loco
    loco = 0
    loco += inv['loco']
    if smallRoute.color == 'grey' or smallRoute.color == 'gray':
        for color in inventory:
            if color != 'loco':
                if inventory.get(color, 0) + loco >= smallRoute.trains - smallRoute.loco:
                    return True
        return False
    elif isinstance(smallRoute.color, list):
        for color in smallRoute.color:
            if color != 'grey' and color != 'gray':
                if inventory.get(color, 0) + loco >= smallRoute.trains - smallRoute.loco:
                    return True
            else:
                for color in inventory:
                    if color != 'loco':
                        if inventory.get(color, 0) + loco >= smallRoute.trains - smallRoute.loco:
                            return True
                    else:
                        if loco >= smallRoute.trains - smallRoute.loco:
                            return True
        return False
    else:
        if inventory.get(smallRoute.color, 0) + loco >= smallRoute.trains - smallRoute.loco:
            return True
        return False

def getClosestCity(app, cities, mouseX, mouseY):
        bestDistance = None
        bestCity = None
        for city in cities:
            distanceToCity = distance(mouseX, mouseY, city.x * app.mapWidth, city.y * app.mapHeight)
            if bestDistance == None or distanceToCity < bestDistance:
                bestCity = city
                bestDistance = distanceToCity
        return bestCity
        
def highlightCities(app, fro, to):
    app.highlightCity1 = fro
    app.highlightCity2 = to

def clickDownCard(downCards, mouseX, mouseY):
    for downCard in downCards:
        if downCard.didClick(mouseX, mouseY):
            return True
    return False

def getDownIndex(downCards, mouseX, mouseY):
    for i in range(len(downCards)):
        if downCards[i].didClick(mouseX, mouseY):
            return i

def clickRouteCard(routeCards, mouseX, mouseY):
    for routeCard in routeCards:
        if routeCard.didClick(mouseX, mouseY):
            return True
    return False

def getRouteIndex(routeCards ,mouseX, mouseY):
    for i in range(len(routeCards)):
        if routeCards[i].didClick(mouseX, mouseY):
            return i

def redrawAll(app):
    if app.gameStart:
        drawGameStart(app)
    elif app.instructions:
        drawInstructions(app)
    elif app.gameOver:
        drawGameOver(app)
    elif app.isQuestionStatement > 0:
        drawBuildColor(app, app.currentPlayer, app.width//120 + len(app.currentPlayer.routes)*app.width//12*1.2, app.height*10//11, app.width//18, app.height//12)
        drawQuestionStatement(app)
    else:
        if app.playerHas2:
            drawLabel('LAST TURN!', app.build.left+app.build.width//2, app.build.top - app.build.height//2, size = app.height//30, bold = True, fill = 'red')
        if app.buildMode:
            drawImage(app.url, app.mapLeft,app.mapTop, width = app.mapWidth , height = app.mapHeight)
            drawRoutes(app, app.players)
            drawBuild(app, app.build)
            drawBuildColor(app, app.currentPlayer, app.width//120 + len(app.currentPlayer.routes)*app.width//12*1.2, app.height*10//11, app.width//18, app.height//12)
            if app.highlightCity1 != None or app.highlightCity2 != None:
                drawHighlightedCities(app, app.highlightCity1, app.highlightCity2, app.currentPlayer.color)
        else:
            drawRect(0,0,app.width, app.height, fill = gradient('white', app.currentPlayer.color), opacity = 40)
            drawImage(app.url, app.mapLeft,app.mapTop, width = app.mapWidth , height = app.mapHeight) 
            drawRoutes(app, app.players)
            drawCondition(app.instructButton, 'instructions', 'papayaWhip')
            drawRandomCard(app, app.bank, app.randomCard)
            drawBankCards(app, app.bank, app.downCards)
            if app.highlightCity1 != None and app.highlightCity2 != None:
                drawHighlightedCities(app, app.highlightCity1, app.highlightCity2, 'indigo')
            if app.currentTurnOver != 'Almost':
                drawRouteCards(app,app.routeCards, app.currentPlayer)
                drawColorCards(app, app.currentPlayer, app.width//120 + len(app.currentPlayer.routes)*app.width//12*1.2, app.height*3//5+ app.height//8, app.width//18, app.height//10)
                if app.currentTurnOver == False and app.cardsTakenCount != 1:
                    drawBuild(app, app.build)
                elif app.currentTurnOver == True:
                    drawEndTurn(app, app.endTurn)
                drawTurnsLobby(app, app.lobbys)
            else:
                drawRYPlayer(app, app.RYPlayer)
    
    # drawLabel(app.message, app.width/2, app.height*3/4, size = 30)

def drawGameOver(app):
    drawImage(app.podium, 0, 0, width = app.width, height = app.height)
    drawCondition(app.gameRestart, 'Restart!', gradient('white', 'peachPuff'))
    drawLeads(app)
    
def drawLeads(app):
    for i in range(len(app.leads)):
        if len(app.players) > i and app.players[i] != None:
            drawLead(app.leads[i], app.players[i])

def drawLead(lead, player):
    drawRect(lead.left, lead.top, lead.width, lead.height, fill = player.color)
    drawLabel(f'Name: {player.name}',lead.left+lead.width//2, lead.top+lead.height//3, size = (lead.height + lead.width)//20)
    drawLabel(f'Points: {player.score}',lead.left+lead.width//2, lead.top+lead.height*2//3, size = (lead.height + lead.width)//20)

def drawInstructions(app):
    manual1 = app.manuals[app.instructPage*2]
    manual2 = app.manuals[app.instructPage*2+1]
    drawManuals(app, manual1, manual2)
    drawCondition(app.instructNext, 'Next', 'powderBlue')
    drawCondition(app.instructBack, 'Back', 'powderBlue')
    drawCondition(app.instructHome, 'Home', 'papayaWhip')

def drawManuals(app, manual1, manual2):
    drawImage(manual1, 0,0, width = app.width//2,height = app.height)
    drawImage(manual2, app.width//2,0, width = app.width//2,height = app.height)

def drawGameStart(app):
    # The Link --> 'https://wallpapercave.com/wp/wp5397682.jpg'
    drawImage('Images/wallPaper.jpeg', 0, 0, width = app.width, height = app.height)
    if app.currPlayers == None:
        drawImage(app.title, app.width//4, app.height*3//8, width = app.width//2, height = app.height//4)
    else:
        drawSubmit(app.submit, 'Start!')
    drawPlayersNum(app)
    for i in range(len(app.playerDropdowns)):
        if app.playerDropdowns[i] != None:
            drawDropdown(app.playerDropdowns[i])
            drawPlayerNames(app, app.playerNameButtons[i], i)
            if not isinstance(app.playerSubmits[i], bool):
                drawSubmit(app.playerSubmits[i], 'Submit')
    if app.submitFlag == 1:
        drawLabel("Please Choose Color before submitting", app.width//2, app.height//2, size = app.height//20, bold = True, fill = 'blue')
        drawLabel("Click anywhere to continue.", app.width//2, app.height//2 + app.height // 18, size = app.height//20, bold = True, fill = 'blue')
        

def drawPlayerNames(app,button, i):
    fill = 'orange' if app.currentName == i else 'yellow'
    border = 'blue' if app.currentName == i else 'black'
    drawRect(button.left, button.top, button.width, button.height, fill = fill, border = border)
    drawLabel(f'{app.playerNames[i]}', button.left + button.width//2, button.top + button.height//2, size = (app.width+app.height)//100)

def drawSubmit(submit, label):
    drawRect(submit.left, submit.top, submit.width, submit.height, fill = 'green', border = 'black')
    drawLabel(label, submit.left + submit.width//2, submit.top + submit.height//2, size = (submit.width + submit.height)//10)

def drawPlayersNum(app):
    i = 1
    drawLabel('How many players are playing?', (app.width//100 + app.playersNum[0].left)//2, app.playersNum[0].top + app.playersNum[0].height//2, size = (app.width+app.height)//100)
    for players in app.playersNum:
        i += 1
        border = None
        if players == app.currPlayers:
            border = 'yellow'
        drawRect(players.left, players.top, players.width, players.height, fill = 'white', border = border)
        drawLabel(str(i), players.left+players.width//2, players.top + players.height//2, size = (app.width+app.height)//100)

def drawRoutes(app, players):
    for player in players:
        for fro, to, trains in player.citiesConnected:
            if trains >= 1:
                drawHighlightedCities(app, fro, to, player.color, player)
            else:
                drawCircle(app.mapLeft + (app.selectCity1.x*app.mapWidth + app.selectCity2.x*app.mapWidth)//2, app.mapTop + (app.selectCity2.y*app.mapHeight + app.selectCity1.y*app.mapHeight)//2, (app.height+app.width)//150, fill = color, border = 'black')


def drawQuestionStatement(app):
    drawRect(0,0,app.width, app.height*9//10, fill = 'white', opacity = 80)
    drawRect(app.width//3, app.height//3, app.width//3, app.height//3, fill = 'white')
    mainLabel = ''
    if app.isQuestionStatement == 1:
        drawCondition(app.yes, 'Yes!', 'lightGreen')
        drawCondition(app.no, 'No', 'lightCoral')
        mainLabel = f'Do you want to build from {app.selectCity1} to {app.selectCity2} with {app.smallRoute.color}'
    elif app.isQuestionStatement == 2:
        mainLabel = f'Building from {app.selectCity1} to {app.selectCity2} is not possible'
        if app.smallRoute == None:
            pass
        elif app.smallRoute.taken != None:
            drawLabel('because it is already taken', app.width//2, app.height * 2 // 6 + (app.width + app.height)//25, bold = True, size = (app.width + app.height)//50)
        drawCondition(app.ok, 'Ok', 'lightCyan')
    elif app.isQuestionStatement == 3:
        mainLabel = f'Select what color cards to use or cancel'
        drawCondition(app.no, 'No', 'lightCoral')
        drawDropdown(app.currentDropdown)
    elif app.isQuestionStatement == 4:
        drawRandomCard(app, app.bank, app.randomCard)
        drawfewDiscardCards(app, app.bank, app.width//120 + app.width//15, app.height//8, app.width//20, app.height//10)
        if app.tunnelFlag:
            mainLabel = f'You have enough to build from {app.selectCity1} to {app.selectCity2}!'
            drawLabel(f'Do you want to use {app.extra} extra cards to build?', app.width//2, app.height * 2 // 6 + (app.width + app.height)//50, bold = True, size = (app.width + app.height)//50)
            drawCondition(app.no,'No', 'lightCoral')
            drawCondition(app.yes, 'Yes!', 'lightGreen')
        else:
            mainLabel = f'You do not have enough to build from {app.selectCity1} to {app.selectCity2}'
            drawLabel('Better Luck next time', app.width//2, app.height * 2 // 6 + (app.width + app.height)//50, bold = True, size = (app.width + app.height)//50)
            drawCondition(app.ok, 'Ok', 'lightCyan')

    drawLabel(mainLabel, app.width//2, app.height * 2 // 6, bold = True, size = (app.width + app.height)//50)

def drawDropdown(currentDropdown):
    color = 'grey' if currentDropdown.open else 'white'
    drawCondition(currentDropdown.trigger, currentDropdown.triggerText, color)
    if currentDropdown.open:
        for i in range(currentDropdown.realOptions):
            drawCondition(currentDropdown.options[i], currentDropdown.texts[i], 'white')

def drawfewDiscardCards(app, bank, left, top, width, height):
    car = -1 * app.discardCount if app.discardCount != 0 else len(bank.discardCards)
    lastfew = bank.discardCards[car:]
    drawLabel('The Discarded Cards Are...', left + 1.5* width, top - .5*height, size = (app.width + app.height)//100)
    for i in range(len(lastfew)):
        color = lastfew[i].color
        drawColorCard(app, bank, left, top, width, height, color, 0)
        left = left + 1.2* width

def drawCondition(condition, label, color):
    drawRect(condition.left, condition.top,condition.width, condition.height, fill = color, border = 'black')
    drawLabel(str(label), condition.left + condition.width//2, condition.top + condition.height//2, size = (condition.width + condition.height)//12)

def drawTurnsLobby(app, lobbys):
    players = copy.copy(app.players)
    newPlayer = app.currentPlayer
    for lobby in lobbys:
        if lobby != None:
            drawRect(lobby.left, lobby.top, lobby.width, lobby.height, fill = newPlayer.color, opacity = 80, border = 'black')
            drawLabel(f'Name: {newPlayer.name}', lobby.left+lobby.width//2, lobby.top+lobby.height//4, size = (lobby.width + lobby.height)//20)
            drawLabel(f'Trains Left: {newPlayer.trainsLeft}', lobby.left+lobby.width//2, lobby.top+lobby.height*2//4, size = (lobby.width + lobby.height)//20)
            drawLabel(f'Routes Doing: {len(newPlayer.routes)}', lobby.left+lobby.width//2, lobby.top+lobby.height*3//4, size = (lobby.width + lobby.height)//20)
            newPlayer = toggleList(players, newPlayer)

def drawHighlightedCities(app, city1, city2, color, player = None):
    smallRoute = findSmallRoute(app, smallRoutes, city1, city2)
    if smallRoute == None:
        if city1 != None:
            drawCircle(app.mapLeft + city1.x*app.mapWidth, app.mapTop + city1.y*app.mapHeight, (app.height+app.width)//300, fill = color)
        if city2 != None:
            drawCircle(app.mapLeft + city2.x*app.mapWidth, app.mapTop + city2.y*app.mapHeight, (app.height+app.width)//300, fill = color)
            drawLine(app.mapLeft + city1.x*app.mapWidth, app.mapTop + city1.y*app.mapHeight, app.mapLeft + city2.x*app.mapWidth, app.mapTop + city2.y*app.mapHeight, fill = color, lineWidth = 6)
    elif smallRoute.taken == player:
        drawCircle(app.mapLeft + city1.x*app.mapWidth, app.mapTop + city1.y*app.mapHeight, (app.height+app.width)//300, fill = color, border = 'black')
        drawCircle(app.mapLeft + city2.x*app.mapWidth, app.mapTop + city2.y*app.mapHeight, (app.height+app.width)//300, fill = color, border = 'black')
        drawLine(app.mapLeft + city1.x*app.mapWidth, app.mapTop + city1.y*app.mapHeight, app.mapLeft + city2.x*app.mapWidth, app.mapTop + city2.y*app.mapHeight, fill = 'black', lineWidth = 8)

        drawLine(app.mapLeft + city1.x*app.mapWidth, app.mapTop + city1.y*app.mapHeight, app.mapLeft + city2.x*app.mapWidth, app.mapTop + city2.y*app.mapHeight, fill = color, lineWidth = 6)
    else:
        drawCircle(app.mapLeft + city1.x*app.mapWidth-6, app.mapTop + city1.y*app.mapHeight-6, (app.height+app.width)//300, fill = color, border = 'black')
        drawCircle(app.mapLeft + city2.x*app.mapWidth-6, app.mapTop + city2.y*app.mapHeight-6, (app.height+app.width)//300, fill = color, border = 'black')
        drawLine(app.mapLeft + city1.x*app.mapWidth-6, app.mapTop + city1.y*app.mapHeight-6, app.mapLeft + city2.x*app.mapWidth-6, app.mapTop + city2.y*app.mapHeight-6, fill = 'black', lineWidth = 14)

        drawLine(app.mapLeft + city1.x*app.mapWidth-6, app.mapTop + city1.y*app.mapHeight-6, app.mapLeft + city2.x*app.mapWidth-6, app.mapTop + city2.y*app.mapHeight-6, fill = color, lineWidth = 6)
        
def drawEndTurn(app, endTurn):
    drawRect(endTurn.left, endTurn.top, endTurn.width, endTurn.height, fill = 'yellow', border = 'black')
    label = "End Turn" if app.lastFlag == 0 else 'End Game!'
    drawLabel(label, endTurn.left+endTurn.width//2, endTurn.top+endTurn.height//2, size = (endTurn.width+endTurn.height)//10)

def drawRouteCards(app, routes, player):
    for i in range(len(player.routes)):
        if player.routes[i] != None:
            drawRouteCard(app, player, routes[i].left, routes[i].top, routes[i].width, routes[i].height, i)

def drawRouteCard(app, player, left, top, width, height, i):
    drawRect(left, top, width, height, fill = player.color, border = 'black')
    drawLabel(str(player.routes[i].fro), left+width//2, top+height//3, size = (width + height)//20)
    drawLabel(str(player.routes[i].to), left+width//2, top+height*2//3, size = (width + height)//20)
    drawLabel(str(player.routes[i].points), left+width//2, top+height*4//5, size = (width + height)//20)

def drawBuildColor(app, player, left ,top, width, height):
    for i in range(len(app.colorCards)):
        color = app.colorCards[i]
        if color in player.inventory:
            drawColorCard(app, player, left, top, width, height, color, j=0)
            drawLabel(str(player.inventory[color]), left+width//2, top-(width + height)//15, size = (width + height)//8)

        left = left + 1.2* width 

def drawColorCards(app, player, left, mainTop, width, height):
    for i in range(len(app.colorCards)):
        color = app.colorCards[i]
        if color in player.inventory:
            drawLabel(str(player.inventory[color]), left+width//2, mainTop-height//6, size = (width + height)//10)
            top = mainTop
            for j in range(player.inventory[color]):
                drawColorCard(app, player, left, top, width, height, color, j)
                top = top + .4 * height
        left = left + 1.2* width 

def drawColorCard(app, player, left, top, width, height, color, j=0):
    if j < 5:
        if color == 'loco':
            drawImage(app.locoCard, left, top, width=width, height=height, border = 'gold')
        elif color == 'yellow':
            drawImage(app.yellowCard, left, top, width=width, height=height, border = 'gold')
        elif color == 'orange':
            drawImage(app.orangeCard, left, top, width=width, height=height, border = 'gold')
        elif color == 'red':
            drawImage(app.redCard, left, top, width=width, height=height, border = 'gold')
        elif color == 'blue':
            drawImage(app.blueCard, left, top, width=width, height=height, border = 'gold')
        elif color == 'green':
            drawImage(app.greenCard, left, top, width=width, height=height, border = 'gold')
        elif color == 'black':
            drawImage(app.blackCard, left, top, width=width, height=height, border = 'gold')
        elif color == 'pink':
            drawImage(app.pinkCard, left, top, width=width, height=height, border = 'gold')
        elif color == 'white':
            drawImage(app.whiteCard, left, top, width=width, height=height, border = 'gold')
        
        

def drawBankCards(app, bank, downCards):
    for i in range(len(bank.downCards)):
        if bank.downCards[i] != None:
            color = bank.downCards[i].color
            drawColorCard(app, app.bank, downCards[i].left, downCards[i].top, downCards[i].width, downCards[i].height, color)

def drawRandomCard(app, bank, randomCard):
    drawImage(app.randomCardImage, randomCard.left, randomCard.top, width = randomCard.width, height = randomCard.height, border = 'gold')
    label = str(len(bank.cards)) if len(bank.cards) > 0 else str(len(bank.discardCards))
    drawLabel(label, randomCard.left + randomCard.width//2, randomCard.top - randomCard.height//4)

def drawRYPlayer(app, RYPlayer):
    drawRect(0,0,app.width, app.height, fill = 'white', opacity = 80)
    drawRect(RYPlayer.left, RYPlayer.top, RYPlayer.width, RYPlayer.height, fill = 'white', border = 'black')
    drawLabel(f'Are You {app.currentPlayer.name}?', RYPlayer.left+RYPlayer.width//2, RYPlayer.top + RYPlayer.height//2, size = (RYPlayer.width+RYPlayer.height)//20)

def drawBuild(app, build):
    drawRect(build.left, build.top, build.width, build.height, fill = 'green', border = 'black')
    label = 'Build!' if not app.buildMode else 'Back Home'
    drawLabel(label, build.left+build.width//2, build.top+build.height//2, size = (build.width+build.height)//10)


def main():
    width = 1000
    runApp(width = width, height = width*3//4)

main()